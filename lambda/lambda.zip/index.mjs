import { SESClient } from "@aws-sdk/client-ses";
import { SendEmailCommand } from "@aws-sdk/client-ses";

import axios from "axios";

const url_api = "https://mailmanjs-git.vercel.app";

const url_api_campaign = url_api + "/api/campaign/retrieve/";
const url_api_start = url_api + "/api/campaign/start/";
const url_api_fail = url_api + "/api/campaign/fail/";
const url_api_finish = url_api + "/api/campaign/finish/";
const url_api_bounce = url_api + "/api/campaign/bounce/";
const url_api_unsub = url_api + "/unsubscribe/";

const symbol_unsub = "##!!UNSUBSCRIBE!!##";
const symbol_open = "##!!OPEN!!##";
const symbol_body = "</body>";

const tag_open = `<img src="${url_api}/api/campaign/open/##!!OPEN!!##" height="1" width="1" alt="" class="CToWUd" data-bit="iit"></body>`;

export const handler = async (event, context) => {
  const campaignId = event.campaignId;
  const url_campaign = url_api_campaign + campaignId;

  const response = await axios.get(url_campaign);
  if (response.error) {
    const url_fail = url_api_fail + campaignId;
    await axios.post(url_fail);
    return;
  }

  const campaign = response.data;

  if (campaign.state === "scheduled") {
    const url_start = url_api_start + campaignId;
    await axios.post(url_start);
  }

  const from = campaign.from;
  const customers = campaign.customers;
  const subject = campaign.subject;
  const html = campaign.html;

  const sesClient = new SESClient();

  for (let i = 0; i < customers.length; i++) {
    const subEmail = customers[i];

    const url_unsubscribe = url_api_unsub + campaignId + "/" + subEmail;
    const html_unsub = html.replace(symbol_unsub, url_unsubscribe);

    const url_open = campaignId + "/" + subEmail;
    const tag_open_final = tag_open.replace(symbol_open, url_open);

    const html_final = html_unsub.replace(symbol_body, tag_open_final);

    const command = new SendEmailCommand({
      Source: from,
      Destination: {
        ToAddresses: [subEmail]
      },
      Message: {
        Subject: {
          Data: subject
        },
        Body: {
          Html: {
            Data: html_final
          }
        }
      }
    });
    try {
      await sesClient.send(command);
    } catch (error) {
      const url_bounce = url_api_bounce + campaignId + "/" + subEmail;
      await axios.post(url_bounce);
    }
  }

  const url_finish = url_api_finish + campaignId;
  await axios.post(url_finish);
};
